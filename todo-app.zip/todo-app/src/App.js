
import './App.css';
import TodoList from './components/TodoList';

function App() {
  return (
    <div className="App">
        <h6  style={{color:'#b5449b'}}>Todo App</h6>
        <hr />
        <TodoList />
    </div>
    
  );
}

export default App;
