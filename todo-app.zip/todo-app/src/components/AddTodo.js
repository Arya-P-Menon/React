import React, { Component } from 'react';

export default class AddTodo extends Component {
    state = {Id:0, Task : "", Status : "Pending"};

    handleSubmit = () => {
        // handleSubmit = (event) => {
        //     event.preventDefault();
        this.props.onAdd({Id:this.state.Id, Task : this.state.Task, Status : this.state.Status});
        this.setState({Id:0, Task : "", Status : "Pending"});
    }

    render() {
        return (
            <div>
                <h1 style={{color:'#55b0c0'}}>Add Todo</h1>
                <form onSubmit={this.handleSubmit}>
                    <table className="table table-dark">
                        <tr>
                            <td><label>Id</label></td>
                            <td><input value={this.state.Id} onChange={e => this.setState({Id: e.target.value})}/></td>
                        </tr>

                        <tr>
                            <td><label>Task</label></td>
                            <td><input value={this.state.Task} onChange={e => this.setState({Task: e.target.value})}/></td>
                        </tr>

                        <tr>
                            <td><label>Status</label></td>
                            <td>
                               <input type="radio" name="status" onClick={e => this.setState({Status : "Pending"})}/>Pending
                               <input type="radio" name="status" onClick={e => this.setState({Status : "COmpleted"})}/>Completed
                            </td>
                            {/* <td><input value={this.state.Status} onChange={e => this.setState({Status: e.target.value})}/></td> */}
                        </tr>
                        <th colSpan="2">
                            <button type="submit">Add Todo</button> 
                        </th>
                    </table>
                    
                </form>
            </div>
        )
    }

}