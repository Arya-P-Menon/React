import {Component} from 'react';
import AddTodo from './AddTodo';

export default class TodoList extends Component {
    state = {
        todos : [
            {Id:1, Task:"Develop the code", Status : "Completed"},
            {Id : 2 , Task : "Commit and push to git", Status : "Pending"}
        ]
    };

    addTodo = (todo) => {
        this.setState({
            todos: [...this.state.todos, todo]
        });
    }

    deleteTodo = (todo) => {
        const filteredTodos = this.state.todos.filter(x => x.Id !== todo.Id);
        this.setState({todos : filteredTodos})
    }

    toggleStatus = (todo) => {
        this.setState(state => ({
            todos : state.todos.map(x => {
                if(x.Id === todo.Id) {
                    return {
                        ...x,
                        Status : x.Status === "Pending" ? "Completed" : "Pending"
                    };
                } else {
                    return x;
                }
            })
        }));
    }

    render() {
        return(
            <div>
                <AddTodo onAdd={this.addTodo} />
                <h1  style={{color:'#55b0c0'}}>Todo List</h1>
                <table className= "table table-dark">
                    <thead><tr>
                        <th>Id</th>
                        <th>Task</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr></thead>
                    <tbody>
                        {this.state.todos.map(x=>{
                            return(
                                <tr key={x.Id}>
                                    <td>{x.Id}</td>
                                    <td>{x.Task}</td>
                                    <td><a onClick={ ()=> this.toggleStatus(x)}>{x.Status}</a></td>
                                    <td><button onClick={() => this.deleteTodo(x)}>Delete</button></td>
                                </tr>
                            )
                        })}
                    </tbody>
                </table>
            </div>
        )
    }
}