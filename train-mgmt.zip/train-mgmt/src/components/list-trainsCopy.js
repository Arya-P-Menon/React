import React, { Component } from 'react';
import TrainService from '../services/train-service';

export default class ListTrains extends Component {
    constructor(props) {
        super(props);
        this.service = new TrainService();
        this.state = {
            train:null
        }
    }

    componentDidMount() {
        this.setState({trains:this.service.getTrain()});
    }

    render() {

        if(!this.state.trains)
            return null;
        
        const TrainRows = this.state.trains.map((x) => 
            <tr>
                <td>{x.tcode}</td>
                <td>{x.name}</td>
                <td>{x.source}</td>
                <td>{x.destiny}</td>
            </tr>
        );

        return (
            <table className = "table table-border">
                <tr>
                    <th>Code</th><th>Name</th><th>Source</th><th>Destiny</th>
                </tr>
                {TrainRows}
            </table>
        )
    }
}