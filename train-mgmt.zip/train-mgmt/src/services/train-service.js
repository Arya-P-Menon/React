export default class TrainService {
    constructor() {
        this.trains= [
            {tcode : 123, name:"Kochi Expo", source : "Goa", destiny : "Kochi"},
            {tcode : 456, name:"Goa Expo", source : "Kochi", destiny : "Goa"},
            {tcode : 789, name:"Bangalore Expo", source : "Kochi", destiny : "Bangalore"}
        ];
    }

    getTrain() {
        return this.trains;
    }

    getTrainByCode(tcode) {
        return this.trains.find(x => x.tcode === tcode);
    }

    saveTrain(train) {
        this.trains.push(train);
    }

    deleteTrain(tcode) {
        this.trains.splice(this.trains.indexOf(this.trains.find(x => x.tcode === tcode)), 1);
    }

    updateTrain(train) {
        var idx = this.trains.indexOf(this.trains.find(x => x.tcode === train.tcode));
        this.trains[idx]=train;
    }
}