

export default class TrainRestService {

    constructor() {
        this.uri = "http://localhost:8880" ;
        this.train = [];
    }


        async getTrains() {
            return fetch(this.uri+"/trains").then(response => {
            if(!response.ok) {
                this.handleResponseError(response);
            }
            return response.json();
        }).then(data => {
            console.log(data);
            this.trains = data;
            return this.trains;
        }).catch(error => {
            console.log(error);
        });
    }

    async getTrainByCode(tcode) {
        return await fetch(this.uri+"/train/"+tcode).then(response => {
            if(!response.ok) {
                this.handleResponseError(response);
            }
            return response.json();
        }).then(data => {
            console.log(data);
            this.trains = data;
            return this.trains;
        }).catch(error => {
            console.log(error);
        });  
    }

    async saveTrain(train) {
        return await fetch(this.uri+"/train", {
            method:"POST",
            mode:"cors",
            headers: {
                "content-type":"application/json"
            },
            body:JSON.stringify(train)
        }).then(response => {
            if(!response.ok) {
                this.handleResponseError(response);
            }
            return response.json();
        }).catch(error => {
            console.log(error.message); 
        });
    }

    async deleteTrain(tcode) {
        return await fetch(this.uri+"/delTrain/"+tcode, {
            method:"DELETE", 
            mode:"cors"
        }).then(response => {
            if(!response.ok) {
                this.handleResponseError(response);
            }
            return response.json();
        }).catch(error => {
            console.log(error.message); 
        });
    }

    async updateTrain(train) {
        return await fetch(this.uri+"/train/update", {
            method:"PUT",
            mode:"cors",
            headers: {
                "content-type":"application/json"
            },
            body:JSON.stringify(train)
        }).then(response => {
            if(!response.ok) {
                this.handleResponseError(response);
            }
            return response.json();
        }).catch(error => {
            console.log(error.message); 
        });
    }
}