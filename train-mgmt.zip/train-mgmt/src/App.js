import './App.css';
import ListTrains from './components/list-trains';

function App() {
  return (
    <div className="App">
         <ListTrains />
    </div>
  );
}

export default App;
