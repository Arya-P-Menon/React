import './App.css';
import Clock from './components/Clock';
// import Demo from "./components/Demo";
// import Show from "./components/Show";
// import Chow from "./components/Show";
// //imported using different name
// import Parent from "./components/Parent";
// import Sample from "./components/Sample";
import Login from "./components/Login";
import Routers from './components/Router';
import Toggle from './components/Toggle';
import Visitor from './components/Visitor';
import VisitorClass from './components/VisitorClass';

function App() {
  return (
    <div className="App">
      <h1>Learning React</h1>
      {/* <Demo author="Arya" date="today"/>
      <Show design="LoveForm" date="today"/>
      <Chow /> 
      <hr />
      <Parent />
      <Sample /> 
      <hr />
      <Login /> 
      <hr />
      <Clock date={new Date()}/>*/}
      {/* <hr />
      <Visitor />
      <hr />
      <Toggle />
      <hr />
      <VisitorClass /> */}

      <hr />

      <Routers />
    </div>
  );
}

export default App;
