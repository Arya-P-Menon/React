import React, {Component} from 'react';

class Show extends Component {
    render(props) { 
        return (
            <h1>Hello from Class Component designed by {this.props.design || 'Arya P Menon'} on {this.props.date || "unknown"}</h1>
        );
    }
}

export default Show;