import React from 'react';

 function Visitor() {
    const [count, setCount] = React.useState(1)
  
    return (
      <div>
        <div>Visitor number : {count}</div>
        <button onClick={() => setCount(c => c + 1)}>Refresh</button> <br />
        <a href="#" onClick={() => setCount(c => c + 1)}>Click Here</a>
      </div>
    )
  }

  export default Visitor