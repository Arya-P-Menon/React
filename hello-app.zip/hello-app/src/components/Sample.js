import React, {Component} from 'react';

export default class Sample extends Component {

    state = { msg : "Not Clicked Yet!"}

    changeState = () => {
        console.log("Inside Event Function");
        //this.state.msg = "Button Clicked";
        this.setState({msg : "Button Clicked!"});
    }
    //should be as lambda function as it is not called as a normal function

    render() {
        return (
            <div>
                <h1>{this.state.msg}</h1>
                <button onClick={this.changeState}>Click Here</button>
            </div>
        );
    }
}