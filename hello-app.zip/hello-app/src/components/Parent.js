import React, {Component} from 'react';
import Child from './Child';
import Demo from './Demo';

export default class Parent extends Component {
    render() {
        return(
            <div>
            <h1>Hello from Parent Component</h1>
            <Child greeting="Hello from parent to child"/>
            <Demo author="Parent" />
        </div>
        );
    }
}