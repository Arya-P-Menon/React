import React, { Component } from 'react';

export default class VisitorClass extends Component{
    state={count : 0};

    counter=() => {
        this.setState({count : this.state.count+1})
    }

    render() {
        return(
            <div>
                <h1>Visitor number : {this.state.count}</h1>
                <button onClick={this.counter}>Refresh</button> <br />
                <a href="#" onClick={this.counter}>Click Here</a>
            </div>
        );
    }
}