
// function Demo() {
//     return (
//         <h1>Hello from Function Component</h1>
//     );
// }


// const Demo =() => {
//     return (
//         <h1>Hello from Function Component</h1>
//     );
// }



const Demo = (props) => (
    <h1>Hello from Function Component by {props.author} on {props.date || "Today"}</h1>
);

export default Demo;