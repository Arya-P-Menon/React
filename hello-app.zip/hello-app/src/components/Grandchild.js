import React, {Component} from 'react';


export default class Grandchild extends Component {
    render(props) {
        return(
                <h1>Hello from GrandChild Component</h1>
        );
    }
}