import React, {Component} from 'react';
import Grandchild from './Grandchild';

export default class Child extends Component {
    render(props) {
        return(
            <div>
                <h1>Hello from Child Component</h1>
                <Grandchild />
            </div>

        );
    }
}