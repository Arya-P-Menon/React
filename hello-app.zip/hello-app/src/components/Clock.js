import React, { Component } from 'react';

export default class Clock extends Component {

    state = {date : new Date()};

    tick() {
        this.setState({date : new Date()});
    }

    componentDidMount() {
        this.timer = setInterval(() => this.tick(),1000);
    }

    componentWillUnmount() {
        clearInterval(this.timer);
    }

    render(props) {
        return (
            // <h2>Now it is : {new Date().toLocaleTimeString()}</h2>
            //  <h2>Now it is : {this.props.date.toLocaleTimeString()}</h2>
            <h2>Now it is : {this.state.date.toLocaleTimeString()}</h2>
        )
    }
}