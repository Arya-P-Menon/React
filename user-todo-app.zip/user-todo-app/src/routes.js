import React from 'react';
import {Route, BrowserRouter as Router, Switch, Redirect} from 'react-router-dom';
import Login from './components/login.js';
import NotFound from './components/notfound.js';
import Register from './components/register.js';
import Dashboard from './components/dashboard.js'



const Routes = (props) => (
    <Router {...props}>
        <Switch>
            <Route exact path = "/">
                <Login />
            </Route>
            <Route path = "/login">
                <Login />
            </Route>
            <Route path = "/register">
                <Register />
            </Route>
            <Route path = "/dashboard">
                <Dashboard />
            </Route>
            <Route path = "*">
                <NotFound />
            </Route>
        </Switch>
    </Router>
);

export default Routes;