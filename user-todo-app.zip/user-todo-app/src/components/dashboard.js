import { Component } from "react";
import { withRouter } from "react-router";
 class Dashboard extends Component{

    constructor(props){
        super(props);
        this.state={
            email:null
        }
    }

    componentDidMount(){
        this.checkLogin();
            
        }


        // checkLogin=()=>{
        //      this.setState({
        //         email:localStorage.getItem('token')
        //      });
        //         if(!this.state.email)
        //         this.props.history.push({pathname:"/login"});
                

        // }

        checkLogin=()=>{
            this.setState({
               user:JSON.parse(localStorage.getItem('user'))
            });
               if(!this.state.email)
               this.props.history.push({pathname:"/login"});
               

       }
        
        logout=()=>{
            localStorage.clear();
            this.props.history.push({pathname:"/login"});

        }

        render(){
        return (
             <div>
                 Dashboard page
                 Welcome {this.state.email}
                 <button onClick={this.logout}>logout</button>
             </div>
        );
        }
        
}

export default withRouter(Dashboard);