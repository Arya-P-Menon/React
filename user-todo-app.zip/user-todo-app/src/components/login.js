import React, { Component, useState } from 'react';
import useHistory from "react-router-dom";
import { withRouter} from "react-router-dom"

class Login extends Component {

     constructor(props) {
         super(props);
         this.state = {
             email : null,
             password : null
         }
     }

    onLogin = () => {
        this.service.authenticate(this.state.email, this.state.password).then(data => {
            this.setState
        })
        if(this.state.email && this.state.password) {
            localStorage.setItem("token",this.state.email)
            this.props.history.push({pathname:"/dashboard"});
        }
        else
            alert("Invalid Login");
    }

    handleInput = (event) => {
        this.setState({
            [event.target.name] : event.target.value
        });
    }

    render(){

        return(
            <form onSubmit={this.onLogin}>
                Email : <input value={this.state.email} onChange={this.handleInput} name="email" type="email" /><br/>
                Password : <input value={this.state.password} onChange={this.handleInput} name="password" type="password" /><br/>
                <button type="submit">Login</button>
            </form>
        )
        }
}

export default withRouter(Login);